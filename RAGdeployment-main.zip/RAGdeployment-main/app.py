import os

from flask import Flask, request, jsonify, render_template_string

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter


app = Flask(__name__)


# ============================================================
# GEMINI API KEY
# ============================================================

GOOGLE_API_KEY = os.environ.get("GEMINI_API_KEY")

if not GOOGLE_API_KEY:
    raise ValueError(
        "GEMINI_API_KEY environment variable is missing."
    )


# ============================================================
# GEMINI MODEL
# ============================================================

llm = ChatGoogleGenerativeAI(
    model="gemini-3.6-flash",
    google_api_key=GOOGLE_API_KEY
)


# ============================================================
# KT GUIDE
# ============================================================

kt_guide_content = """
Welcome to InnovateCorp! This Knowledge Transfer (KT) guide is designed to help new employees navigate their initial weeks and understand key aspects of our operations. Our core values are Innovation, Collaboration, and Customer Focus.

Team Structure:
You will be joining the Project Alpha team, reporting to Sarah Chen, the Senior Project Manager. Your direct teammates include David Lee (Lead Developer), Maria Rodriguez (UI/UX Designer), and Tom Jackson (QA Engineer).

Team meetings are held every Monday at 10 AM in Conference Room 3, and daily stand-ups are at 9:30 AM via Google Meet.

Key Tools & Software:
For project management, we use Jira for task tracking and Confluence for documentation. Our primary communication tool is Slack for instant messaging and Google Workspace for email and calendars. Development work is primarily done using Python and JavaScript, with code hosted on GitHub. Access to these tools will be granted within your first three days.

Onboarding Process:
Your first week will focus on setup and introductions. You'll receive your laptop and login credentials on day one. HR will conduct an orientation session on Tuesday covering company policies, benefits, and payroll. You'll have one-on-one meetings with your team members throughout the week. By the end of your second week, you should have access to all necessary systems and have completed mandatory compliance training modules.

Important Resources:
The company's internal knowledge base can be found at internal.innovatecorp.com/kb. This includes FAQs, best practices, and troubleshooting guides. For IT support, please submit a ticket via support.innovatecorp.com or call extension 5555. Health and wellness benefits information is available on the HR portal.

Culture & Expectations:
InnovateCorp encourages a proactive and collaborative environment. We value open communication and continuous learning. Don't hesitate to ask questions; your team is here to support your growth. Performance reviews are conducted quarterly, and professional development courses are available through our InnovateLearn platform.
"""


# ============================================================
# DOCUMENT + CHUNKS
# ============================================================

kt_documents = [
    Document(page_content=kt_guide_content)
]


splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=50
)


kt_chunks = splitter.split_documents(
    kt_documents
)


# ============================================================
# EMBEDDINGS + FAISS
# ============================================================

embeddings = GoogleGenerativeAIEmbeddings(
    model="models/gemini-embedding-001",
    google_api_key=GOOGLE_API_KEY
)


vector_store = FAISS.from_documents(
    kt_chunks,
    embeddings
)


# ============================================================
# TEXT HELPER
# ============================================================

def text_of(response):

    content = getattr(
        response,
        "content",
        response
    )

    if isinstance(content, list):

        parts = []

        for item in content:

            if isinstance(item, dict):

                parts.append(
                    item.get("text", "")
                )

            else:

                parts.append(
                    str(item)
                )

        return " ".join(parts).strip()

    return str(content).strip()


# ============================================================
# RELEVANCE CHECK
# ============================================================

KT_TOPICS = """
InnovateCorp, Project Alpha, Sarah Chen, David Lee,
Maria Rodriguez, Tom Jackson, team structure,
reporting manager, meetings, daily stand-ups,
Jira, Confluence, Slack, Google Workspace,
Python, JavaScript, GitHub, onboarding,
laptop, login credentials, HR orientation,
company policies, benefits, payroll,
one-on-one meetings, compliance training,
internal knowledge base, IT support, HR portal,
company culture, performance reviews,
professional development, InnovateLearn
"""


def is_kt_relevant(query):

    classification_prompt = f"""
Classify the user's question as exactly one:

RELEVANT
IRRELEVANT

The question is RELEVANT only if it is related
to the InnovateCorp KT Guide.

KT Guide topics:
{KT_TOPICS}

General knowledge, sports, politics, jokes,
unrelated programming questions, and unrelated
personal questions are IRRELEVANT.

User question:
{query}

Return ONLY:
RELEVANT
or
IRRELEVANT
"""

    response = llm.invoke(
        classification_prompt
    )

    result = text_of(response).upper()

    return result.startswith("RELEVANT")


# ============================================================
# RETRIEVAL
# ============================================================

def retrieve_kt_context(query):

    retrieved_docs = vector_store.similarity_search(
        query,
        k=3
    )

    if not retrieved_docs:
        return ""

    return "\n\n".join(
        doc.page_content
        for doc in retrieved_docs
    )


# ============================================================
# FINAL ANSWER
# ============================================================

def answer_kt_question(query):

    query = query.strip()

    if not query:

        return {
            "answer": "Please enter a question.",
            "relevant": False,
            "tool_used": False
        }


    # --------------------------------------------------------
    # Relevance is checked BEFORE retrieval.
    # --------------------------------------------------------

    relevant = is_kt_relevant(
        query
    )


    # --------------------------------------------------------
    # Irrelevant question
    # --------------------------------------------------------

    if not relevant:

        return {

            "answer": (
                "This question is outside the InnovateCorp "
                "KT Guide. Please ask about onboarding, "
                "Project Alpha, team roles, company tools, "
                "resources, processes, or company culture."
            ),

            "relevant": False,

            "tool_used": False
        }


    # --------------------------------------------------------
    # Relevant question
    # --------------------------------------------------------

    context = retrieve_kt_context(
        query
    )


    answer_prompt = f"""
You are an InnovateCorp KT Guide assistant.

Answer the user's question using ONLY the KT Guide
context below.

Do not invent information.

If the answer is not available in the context, say:

"That information is not available in the KT Guide."

KT GUIDE CONTEXT:
{context}

USER QUESTION:
{query}

ANSWER:
"""


    response = llm.invoke(
        answer_prompt
    )


    return {

        "answer": text_of(
            response
        ),

        "relevant": True,

        "tool_used": True
    }


# ============================================================
# KTRAG WEB INTERFACE
# ============================================================

HTML = """
<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>KTRAG | Knowledge Transfer Assistant</title>


    <!-- Google Font -->

    <link
        rel="preconnect"
        href="https://fonts.googleapis.com"
    >

    <link
        rel="preconnect"
        href="https://fonts.gstatic.com"
        crossorigin
    >

    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"
        rel="stylesheet"
    >


    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }


        :root {

            --primary: #6366f1;

            --primary-dark: #4f46e5;

            --secondary: #8b5cf6;

            --background: #f5f7ff;

            --card: rgba(255, 255, 255, 0.92);

            --text: #172033;

            --muted: #667085;

            --border: #e6e8f0;

            --success: #16a34a;

            --danger: #dc2626;

        }


        body {

            font-family: "Inter", sans-serif;

            min-height: 100vh;

            background:
                radial-gradient(
                    circle at top left,
                    rgba(99, 102, 241, 0.18),
                    transparent 32%
                ),
                radial-gradient(
                    circle at bottom right,
                    rgba(139, 92, 246, 0.15),
                    transparent 30%
                ),
                var(--background);

            color: var(--text);

            padding: 30px 18px;

        }


        .app-wrapper {

            width: 100%;

            max-width: 1100px;

            margin: auto;

        }


        /* ====================================================
           HEADER
        ==================================================== */

        .header {

            display: flex;

            align-items: center;

            justify-content: space-between;

            gap: 20px;

            margin-bottom: 25px;

        }


        .brand {

            display: flex;

            align-items: center;

            gap: 15px;

        }


        .brand-logo {

            width: 58px;

            height: 58px;

            border-radius: 18px;

            display: flex;

            align-items: center;

            justify-content: center;

            background:
                linear-gradient(
                    135deg,
                    var(--primary),
                    var(--secondary)
                );

            color: white;

            font-size: 25px;

            font-weight: 800;

            box-shadow:
                0 12px 30px
                rgba(99, 102, 241, 0.30);

        }


        .brand-text h1 {

            font-size: 25px;

            font-weight: 800;

            letter-spacing: -0.6px;

        }


        .brand-text p {

            color: var(--muted);

            font-size: 13px;

            margin-top: 3px;

        }


        .status {

            display: flex;

            align-items: center;

            gap: 8px;

            padding: 9px 13px;

            border-radius: 30px;

            background: rgba(255, 255, 255, 0.75);

            border: 1px solid var(--border);

            font-size: 12px;

            font-weight: 600;

            color: #475467;

        }


        .status-dot {

            width: 9px;

            height: 9px;

            background: #22c55e;

            border-radius: 50%;

            box-shadow:
                0 0 0 4px
                rgba(34, 197, 94, 0.12);

        }


        /* ====================================================
           HERO
        ==================================================== */

        .hero {

            position: relative;

            overflow: hidden;

            border-radius: 28px;

            padding: 38px;

            margin-bottom: 22px;

            background:
                linear-gradient(
                    135deg,
                    #111827,
                    #312e81
                );

            color: white;

            box-shadow:
                0 25px 60px
                rgba(31, 41, 55, 0.18);

        }


        .hero::before {

            content: "";

            position: absolute;

            width: 230px;

            height: 230px;

            border-radius: 50%;

            right: -80px;

            top: -100px;

            background:
                rgba(139, 92, 246, 0.25);

            filter: blur(5px);

        }


        .hero::after {

            content: "";

            position: absolute;

            width: 170px;

            height: 170px;

            border-radius: 50%;

            right: 130px;

            bottom: -100px;

            background:
                rgba(99, 102, 241, 0.20);

        }


        .hero-content {

            position: relative;

            z-index: 2;

            max-width: 720px;

        }


        .hero-badge {

            display: inline-flex;

            align-items: center;

            gap: 7px;

            padding: 7px 11px;

            border-radius: 20px;

            background:
                rgba(255, 255, 255, 0.10);

            border:
                1px solid
                rgba(255, 255, 255, 0.15);

            font-size: 11px;

            font-weight: 600;

            margin-bottom: 17px;

        }


        .hero h2 {

            font-size: clamp(28px, 5vw, 43px);

            line-height: 1.1;

            letter-spacing: -1.5px;

            margin-bottom: 13px;

        }


        .hero p {

            color: #dbe2f0;

            font-size: 14px;

            line-height: 1.7;

            max-width: 650px;

        }


        /* ====================================================
           MAIN GRID
        ==================================================== */

        .main-grid {

            display: grid;

            grid-template-columns: 0.85fr 1.6fr;

            gap: 22px;

        }


        /* ====================================================
           INFO CARD
        ==================================================== */

        .info-card {

            background: var(--card);

            border:
                1px solid
                rgba(255, 255, 255, 0.8);

            border-radius: 22px;

            padding: 25px;

            box-shadow:
                0 12px 35px
                rgba(31, 41, 55, 0.07);

            backdrop-filter: blur(12px);

        }


        .info-card h3 {

            font-size: 17px;

            margin-bottom: 17px;

        }


        .topic {

            display: flex;

            gap: 12px;

            align-items: center;

            padding: 13px;

            border-radius: 14px;

            background: #f8f9ff;

            border: 1px solid #eceeff;

            margin-bottom: 10px;

            transition: 0.2s ease;

        }


        .topic:hover {

            transform: translateY(-2px);

            border-color: #d9dcff;

            box-shadow:
                0 8px 20px
                rgba(99, 102, 241, 0.08);

        }


        .topic-icon {

            width: 37px;

            height: 37px;

            border-radius: 11px;

            display: flex;

            align-items: center;

            justify-content: center;

            background: #eef0ff;

            font-size: 17px;

        }


        .topic span {

            font-size: 13px;

            font-weight: 600;

        }


        .info-note {

            margin-top: 18px;

            padding: 14px;

            border-radius: 14px;

            background: #fefce8;

            border: 1px solid #fef08a;

            color: #854d0e;

            font-size: 12px;

            line-height: 1.6;

        }


        /* ====================================================
           CHAT CARD
        ==================================================== */

        .chat-card {

            background: var(--card);

            border:
                1px solid
                rgba(255, 255, 255, 0.8);

            border-radius: 22px;

            box-shadow:
                0 12px 35px
                rgba(31, 41, 55, 0.07);

            overflow: hidden;

            backdrop-filter: blur(12px);

        }


        .chat-header {

            padding: 21px 24px;

            border-bottom:
                1px solid
                var(--border);

            display: flex;

            align-items: center;

            justify-content: space-between;

        }


        .chat-title {

            display: flex;

            align-items: center;

            gap: 11px;

        }


        .bot-icon {

            width: 40px;

            height: 40px;

            border-radius: 13px;

            display: flex;

            align-items: center;

            justify-content: center;

            background:
                linear-gradient(
                    135deg,
                    #eef2ff,
                    #f5f3ff
                );

            font-size: 20px;

        }


        .chat-title strong {

            display: block;

            font-size: 14px;

        }


        .chat-title small {

            color: var(--muted);

            font-size: 11px;

        }


        .clear-btn {

            border: none;

            background: transparent;

            color: #98a2b3;

            cursor: pointer;

            font-size: 12px;

            padding: 7px 10px;

            border-radius: 8px;

        }


        .clear-btn:hover {

            background: #f2f4f7;

            color: #475467;

        }


        /* ====================================================
           CHAT BODY
        ==================================================== */

        .chat-body {

            min-height: 380px;

            max-height: 500px;

            overflow-y: auto;

            padding: 24px;

            background:
                linear-gradient(
                    180deg,
                    #fbfcff,
                    #f8f9fd
                );

        }


        .welcome-message {

            max-width: 580px;

            margin: 25px auto;

            text-align: center;

            color: var(--muted);

        }


        .welcome-icon {

            width: 60px;

            height: 60px;

            margin: auto auto 15px;

            border-radius: 20px;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 28px;

            background:
                linear-gradient(
                    135deg,
                    #eef2ff,
                    #f5f3ff
                );

        }


        .welcome-message h3 {

            color: var(--text);

            font-size: 18px;

            margin-bottom: 8px;

        }


        .welcome-message p {

            font-size: 13px;

            line-height: 1.6;

        }


        .suggestions {

            display: flex;

            flex-wrap: wrap;

            justify-content: center;

            gap: 8px;

            margin-top: 18px;

        }


        .suggestion {

            border: 1px solid #e0e3f0;

            background: white;

            padding: 9px 12px;

            border-radius: 20px;

            color: #475467;

            font-size: 11px;

            cursor: pointer;

            transition: 0.2s;

        }


        .suggestion:hover {

            border-color: #a5b4fc;

            color: var(--primary-dark);

            background: #f8f9ff;

        }


        /* ====================================================
           MESSAGE
        ==================================================== */

        .message {

            display: flex;

            margin-bottom: 18px;

            animation:
                messageIn
                0.25s
                ease;

        }


        @keyframes messageIn {

            from {

                opacity: 0;

                transform: translateY(7px);

            }

            to {

                opacity: 1;

                transform: translateY(0);

            }

        }


        .message.user {

            justify-content: flex-end;

        }


        .message-bubble {

            max-width: 82%;

            padding: 13px 16px;

            border-radius: 17px;

            font-size: 13px;

            line-height: 1.65;

            white-space: pre-wrap;

        }


        .message.assistant
        .message-bubble {

            background: white;

            border:
                1px solid
                var(--border);

            border-bottom-left-radius: 5px;

            color: #344054;

            box-shadow:
                0 5px 15px
                rgba(16, 24, 40, 0.04);

        }


        .message.user
        .message-bubble {

            background:
                linear-gradient(
                    135deg,
                    var(--primary),
                    var(--secondary)
                );

            color: white;

            border-bottom-right-radius: 5px;

            box-shadow:
                0 7px 18px
                rgba(99, 102, 241, 0.20);

        }


        /* ====================================================
           TYPING
        ==================================================== */

        .typing {

            display: flex;

            align-items: center;

            gap: 5px;

            padding: 5px 0;

        }


        .typing span {

            width: 7px;

            height: 7px;

            border-radius: 50%;

            background: #98a2b3;

            animation:
                typing
                1.2s
                infinite;

        }


        .typing span:nth-child(2) {

            animation-delay: 0.15s;

        }


        .typing span:nth-child(3) {

            animation-delay: 0.3s;

        }


        @keyframes typing {

            0%, 60%, 100% {

                transform: translateY(0);

                opacity: 0.5;

            }

            30% {

                transform: translateY(-4px);

                opacity: 1;

            }

        }


        /* ====================================================
           INPUT AREA
        ==================================================== */

        .input-area {

            padding: 18px;

            border-top:
                1px solid
                var(--border);

            background: white;

        }


        .input-box {

            display: flex;

            align-items: flex-end;

            gap: 10px;

            padding: 9px;

            border:
                1px solid
                #dfe3ed;

            border-radius: 17px;

            background: #fbfcff;

            transition: 0.2s;

        }


        .input-box:focus-within {

            border-color: #a5b4fc;

            box-shadow:
                0 0 0 4px
                rgba(99, 102, 241, 0.08);

        }


        textarea {

            flex: 1;

            min-height: 44px;

            max-height: 130px;

            resize: none;

            border: none;

            outline: none;

            background: transparent;

            font-family: inherit;

            font-size: 13px;

            line-height: 1.5;

            padding: 9px 7px;

            color: var(--text);

        }


        textarea::placeholder {

            color: #98a2b3;

        }


        .send-btn {

            width: 44px;

            height: 44px;

            border: none;

            border-radius: 13px;

            background:
                linear-gradient(
                    135deg,
                    var(--primary),
                    var(--secondary)
                );

            color: white;

            cursor: pointer;

            font-size: 18px;

            display: flex;

            align-items: center;

            justify-content: center;

            transition: 0.2s;

        }


        .send-btn:hover {

            transform: translateY(-2px);

            box-shadow:
                0 8px 18px
                rgba(99, 102, 241, 0.25);

        }


        .send-btn:disabled {

            opacity: 0.5;

            cursor: not-allowed;

            transform: none;

        }


        .input-footer {

            display: flex;

            justify-content: space-between;

            margin-top: 8px;

            padding: 0 4px;

            color: #98a2b3;

            font-size: 10px;

        }


        /* ====================================================
           FOOTER
        ==================================================== */

        footer {

            text-align: center;

            margin-top: 22px;

            color: #98a2b3;

            font-size: 11px;

        }


        /* ====================================================
           RESPONSIVE
        ==================================================== */

        @media (max-width: 800px) {

            body {

                padding: 18px 12px;

            }


            .header {

                align-items: flex-start;

            }


            .status {

                display: none;

            }


            .hero {

                padding: 28px 23px;

                border-radius: 22px;

            }


            .main-grid {

                grid-template-columns: 1fr;

            }


            .info-card {

                display: none;

            }


            .chat-body {

                min-height: 400px;

            }

        }


        @media (max-width: 480px) {

            .brand-text h1 {

                font-size: 21px;

            }


            .brand-logo {

                width: 48px;

                height: 48px;

                border-radius: 14px;

            }


            .hero h2 {

                font-size: 28px;

            }


            .message-bubble {

                max-width: 92%;

            }

        }

    </style>

</head>


<body>


<div class="app-wrapper">


    <!-- ==================================================
         HEADER
    =================================================== -->

    <header class="header">

        <div class="brand">

            <div class="brand-logo">
                K
            </div>

            <div class="brand-text">

                <h1>KTRAG</h1>

                <p>
                    Knowledge Transfer & Retrieval AI Guide
                </p>

            </div>

        </div>


        <div class="status">

            <span class="status-dot"></span>

            AI Assistant Online

        </div>

    </header>


    <!-- ==================================================
         HERO
    =================================================== -->

    <section class="hero">

        <div class="hero-content">

            <div class="hero-badge">

                ✦ AI-Powered Knowledge Assistant

            </div>


            <h2>
                Welcome to KTRAG
            </h2>


            <p>
                Your intelligent Knowledge Transfer assistant.
                Ask questions about onboarding, Project Alpha,
                team members, company tools, resources,
                processes and company culture.
            </p>

        </div>

    </section>


    <!-- ==================================================
         MAIN
    =================================================== -->

    <div class="main-grid">


        <!-- ==============================================
             INFORMATION PANEL
        =============================================== -->

        <aside class="info-card">

            <h3>
                What can I help with?
            </h3>


            <div class="topic">

                <div class="topic-icon">
                    🚀
                </div>

                <span>
                    Project Alpha
                </span>

            </div>


            <div class="topic">

                <div class="topic-icon">
                    👥
                </div>

                <span>
                    Team & Roles
                </span>

            </div>


            <div class="topic">

                <div class="topic-icon">
                    🧭
                </div>

                <span>
                    Onboarding Process
                </span>

            </div>


            <div class="topic">

                <div class="topic-icon">
                    🛠️
                </div>

                <span>
                    Tools & Software
                </span>

            </div>


            <div class="topic">

                <div class="topic-icon">
                    📚
                </div>

                <span>
                    Resources
                </span>

            </div>


            <div class="topic">

                <div class="topic-icon">
                    🌱
                </div>

                <span>
                    Culture & Expectations
                </span>

            </div>


            <div class="info-note">

                💡
                Ask questions naturally. KTRAG retrieves
                relevant information from the Knowledge
                Transfer Guide before generating an answer.

            </div>

        </aside>


        <!-- ==============================================
             CHAT
        =============================================== -->

        <section class="chat-card">


            <div class="chat-header">

                <div class="chat-title">

                    <div class="bot-icon">
                        🤖
                    </div>

                    <div>

                        <strong>
                            KTRAG Assistant
                        </strong>

                        <small>
                            Knowledge Transfer Assistant
                        </small>

                    </div>

                </div>


                <button
                    class="clear-btn"
                    onclick="clearChat()"
                >
                    Clear Chat
                </button>

            </div>


            <!-- CHAT BODY -->

            <div
                class="chat-body"
                id="chatBody"
            >

                <div
                    class="welcome-message"
                    id="welcomeMessage"
                >

                    <div class="welcome-icon">
                        ✨
                    </div>

                    <h3>
                        How can I help you?
                    </h3>

                    <p>
                        Ask me anything about the
                        Knowledge Transfer Guide.
                    </p>


                    <div class="suggestions">

                        <button
                            class="suggestion"
                            onclick="useSuggestion('Who is the reporting manager for Project Alpha?')"
                        >
                            Project Alpha manager
                        </button>


                        <button
                            class="suggestion"
                            onclick="useSuggestion('What are the daily stand-up timings?')"
                        >
                            Daily stand-up
                        </button>


                        <button
                            class="suggestion"
                            onclick="useSuggestion('What tools are used by the team?')"
                        >
                            Team tools
                        </button>


                        <button
                            class="suggestion"
                            onclick="useSuggestion('What is the onboarding process?')"
                        >
                            Onboarding
                        </button>

                    </div>

                </div>

            </div>


            <!-- INPUT -->

            <div class="input-area">

                <div class="input-box">

                    <textarea
                        id="question"
                        rows="1"
                        placeholder="Ask KTRAG about the KT Guide..."
                        onkeydown="handleKeyDown(event)"
                        oninput="autoResize(this)"
                    ></textarea>


                    <button
                        class="send-btn"
                        id="sendBtn"
                        onclick="askQuestion()"
                        title="Send"
                    >
                        ➤
                    </button>

                </div>


                <div class="input-footer">

                    <span>
                        KTRAG • AI Knowledge Assistant
                    </span>

                    <span>
                        Press Enter to send
                    </span>

                </div>

            </div>

        </section>

    </div>


    <footer>

        KTRAG • Knowledge Transfer & Retrieval AI Guide

    </footer>


</div>


<script>


    // ========================================================
    // GET ELEMENTS
    // ========================================================

    const questionInput =
        document.getElementById("question");

    const chatBody =
        document.getElementById("chatBody");

    const sendBtn =
        document.getElementById("sendBtn");

    const welcomeMessage =
        document.getElementById("welcomeMessage");


    // ========================================================
    // ASK QUESTION
    // ========================================================

    async function askQuestion() {

        const question =
            questionInput.value.trim();


        // Empty question

        if (!question) {

            questionInput.focus();

            return;

        }


        // Hide welcome screen

        if (welcomeMessage) {

            welcomeMessage.style.display =
                "none";

        }


        // Display user message

        addMessage(
            question,
            "user"
        );


        // Clear input

        questionInput.value = "";

        autoResize(questionInput);


        // Disable send button

        sendBtn.disabled = true;


        // Show typing indicator

        const typingId =
            addTyping();


        try {


            const response =
                await fetch(
                    "/ask",
                    {

                        method: "POST",

                        headers: {

                            "Content-Type":
                                "application/json"

                        },

                        body:
                            JSON.stringify({
                                question:
                                    question
                            })

                    }
                );


            // HTTP error

            if (!response.ok) {

                throw new Error(
                    "Server error: "
                    + response.status
                );

            }


            const data =
                await response.json();


            // Remove typing indicator

            removeTyping(
                typingId
            );


            // Add answer

            addMessage(
                data.answer ||
                "No answer was returned.",
                "assistant"
            );


        } catch (error) {


            console.error(
                "KTRAG Error:",
                error
            );


            removeTyping(
                typingId
            );


            addMessage(
                "I'm sorry, I couldn't connect to KTRAG right now. Please try again.",
                "assistant"
            );


        } finally {

            sendBtn.disabled = false;

            questionInput.focus();

        }

    }


    // ========================================================
    // ADD MESSAGE
    // ========================================================

    function addMessage(
        text,
        sender
    ) {

        const message =
            document.createElement(
                "div"
            );


        message.className =
            "message " + sender;


        const bubble =
            document.createElement(
                "div"
            );


        bubble.className =
            "message-bubble";


        bubble.textContent =
            text;


        message.appendChild(
            bubble
        );


        chatBody.appendChild(
            message
        );


        scrollToBottom();

    }


    // ========================================================
    // TYPING INDICATOR
    // ========================================================

    function addTyping() {

        const id =
            "typing-" +
            Date.now();


        const message =
            document.createElement(
                "div"
            );


        message.className =
            "message assistant";


        message.id =
            id;


        message.innerHTML = `

            <div class="message-bubble">

                <div class="typing">

                    <span></span>

                    <span></span>

                    <span></span>

                </div>

            </div>

        `;


        chatBody.appendChild(
            message
        );


        scrollToBottom();


        return id;

    }


    // ========================================================
    // REMOVE TYPING
    // ========================================================

    function removeTyping(id) {

        const element =
            document.getElementById(
                id
            );


        if (element) {

            element.remove();

        }

    }


    // ========================================================
    // CLEAR CHAT
    // ========================================================

    function clearChat() {

        chatBody.innerHTML = "";


        const welcome =
            document.createElement(
                "div"
            );


        welcome.className =
            "welcome-message";


        welcome.id =
            "welcomeMessage";


        welcome.innerHTML = `

            <div class="welcome-icon">
                ✨
            </div>

            <h3>
                How can I help you?
            </h3>

            <p>
                Ask me anything about the
                Knowledge Transfer Guide.
            </p>

            <div class="suggestions">

                <button
                    class="suggestion"
                    onclick="useSuggestion('Who is the reporting manager for Project Alpha?')"
                >
                    Project Alpha manager
                </button>

                <button
                    class="suggestion"
                    onclick="useSuggestion('What are the daily stand-up timings?')"
                >
                    Daily stand-up
                </button>

                <button
                    class="suggestion"
                    onclick="useSuggestion('What tools are used by the team?')"
                >
                    Team tools
                </button>

                <button
                    class="suggestion"
                    onclick="useSuggestion('What is the onboarding process?')"
                >
                    Onboarding
                </button>

            </div>

        `;


        chatBody.appendChild(
            welcome
        );

    }


    // ========================================================
    // SUGGESTION
    // ========================================================

    function useSuggestion(
        text
    ) {

        questionInput.value =
            text;


        autoResize(
            questionInput
        );


        questionInput.focus();

    }


    // ========================================================
    // ENTER KEY
    // ========================================================

    function handleKeyDown(
        event
    ) {

        if (
            event.key === "Enter"
            &&
            !event.shiftKey
        ) {

            event.preventDefault();

            askQuestion();

        }

    }


    // ========================================================
    // AUTO RESIZE
    // ========================================================

    function autoResize(
        element
    ) {

        element.style.height =
            "auto";


        element.style.height =
            Math.min(
                element.scrollHeight,
                130
            ) + "px";

    }


    // ========================================================
    // SCROLL
    // ========================================================

    function scrollToBottom() {

        setTimeout(
            () => {

                chatBody.scrollTo({

                    top:
                        chatBody.scrollHeight,

                    behavior:
                        "smooth"

                });

            },
            50
        );

    }


    // ========================================================
    // INITIAL FOCUS
    // ========================================================

    questionInput.focus();


</script>


</body>

</html>
"""


# ============================================================
# FLASK ROUTES
# ============================================================

@app.route("/")
def home():

    return render_template_string(
        HTML
    )


@app.route(
    "/ask",
    methods=["POST"]
)
def ask():

    data = request.get_json()

    if not data:

        return jsonify({

            "answer":
                "Please provide a question.",

            "relevant":
                False,

            "tool_used":
                False

        })


    question = data.get(
        "question",
        ""
    )


    result = answer_kt_question(
        question
    )


    return jsonify(
        result
    )


# ============================================================
# RUN
# ============================================================

if __name__ == "__main__":

    port = int(
        os.environ.get(
            "PORT",
            5000
        )
    )


    app.run(

        host="0.0.0.0",

        port=port
    )